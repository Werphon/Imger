#include "mainwindow.h"

//主窗口类
mainwindow::mainwindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui_mainwindow)
{
    this->move(10,10);
    ui->setupUi(this);

    //文件菜单栏
    pMenuFile = new QMenu("文件(&File)");//快捷键：ALT+F
    ui->menuBar->addMenu(pMenuFile);
    //应用菜单栏
    pMenuEdit = new QMenu("编辑(&Edit)");//快捷键：ALT+E
    ui->menuBar->addMenu(pMenuEdit);
    //帮助菜单栏
    pMenuHelp = new QMenu("帮助(&Help)");//快捷键：ALT+H
    ui->menuBar->addMenu(pMenuHelp);

    //边缘检测二级菜单
    pMenuEdge = new QMenu("边缘检测(&D)");//快捷键：ALT+D
    pMenuEdit->addMenu(pMenuEdge);

    //均值滤波二级菜单
    pMenuMean = new QMenu("均值滤波(&M)");//快捷键：ALT+M
    pMenuEdit->addMenu(pMenuMean);

    //打开选项
    pActOpen = new QAction("打开");
    pActOpen->setShortcut(Qt::CTRL|Qt::Key_O);
    pMenuFile->addAction(pActOpen);
    //保存选项
    pActSave = new QAction("保存");
    pActSave->setShortcut(Qt::CTRL|Qt::Key_S);
    pMenuFile->addAction(pActSave);
    //灰度图选项
    pActGray = new QAction("灰度图");
    pActGray->setShortcut(Qt::CTRL|Qt::Key_G);
    pMenuEdit->addAction(pActGray);
    //均值滤波选项
    pActMeanImg = new QAction("模糊值设定");
    pActMeanImg->setShortcut(Qt::CTRL|Qt::Key_M);
    pMenuMean->addAction(pActMeanImg);
    //关于选项
    pActAbout = new QAction("关于");
    pActAbout->setShortcut(Qt::CTRL|Qt::Key_A);
    pMenuHelp->addAction(pActAbout);

    //Canny算法选项
    pActCanny = new QAction("Canny算法");
    pActCanny->setShortcut(Qt::CTRL|Qt::ALT|Qt::Key_C);
    pMenuEdge->addAction(pActCanny);
    //Laplacian算法选项
    pActLaplacian = new QAction("Laplacian算法");
    pActLaplacian->setShortcut(Qt::CTRL|Qt::ALT|Qt::Key_L);
    pMenuEdge->addAction(pActLaplacian);
    //Sobel算法选项
    pActSobel = new QAction("Sobel算法");
    pActSobel->setShortcut(Qt::CTRL|Qt::ALT|Qt::Key_S);
    pMenuEdge->addAction(pActSobel);


    //槽连接
    connect(pActOpen,SIGNAL(triggered()),this,SLOT(Trigger_Open()));//打开
    connect(pActSave,SIGNAL(triggered()),this,SLOT(Trigger_Save()));//保存
    connect(pActGray,SIGNAL(triggered()),this,SLOT(Trigger_Gray()));//灰度图
    connect(pActMeanImg,SIGNAL(triggered()),this,SLOT(Trigger_MeanImg()));//均值滤波
    connect(pActCanny,SIGNAL(triggered()),this,SLOT(Trigger_Canny()));//Canny算法
    connect(pActLaplacian,SIGNAL(triggered()),this,SLOT(Trigger_Laplacian()));//Laplacian算法
    connect(pActSobel,SIGNAL(triggered()),this,SLOT(Trigger_Sobel()));//Sobel算法
}

mainwindow::~mainwindow()
{
    delete ui;
}


void mainwindow::Trigger_Open() //打开原图
{
    //弹出文件选择对话框，选择图片文件
    QString imgPath = QFileDialog::getOpenFileName(this, "Open Image", "../", "Image Files (*.png *.jpeg *.jpg *.bmp);;All Files (*)");
    if(imgPath.isEmpty())return;
    else if(!(imgPath.contains(".jpg")||imgPath.contains(".jpeg")||imgPath.contains(".JPG")||imgPath.contains(".JPEG")) &&\
             !(imgPath.contains(".png")||imgPath.contains(".PNG")) && !(imgPath.contains(".bmp")||imgPath.contains(".BMP")))return;

    srcImage = imread(imgPath.toLocal8Bit().toStdString());   //读取图片文件

    cvtColor(srcImage, srcImage, COLOR_BGR2RGB);    //将BGR格式转换为RGB格式

    //将读取的图片转换为QImage格式
    QImage displayimg = QImage(srcImage.data, srcImage.cols, srcImage.rows, srcImage.cols * srcImage.channels(), QImage::Format_RGB888);

    QImage disImg = imgCenter(displayimg,ui->lbl_Show1);    //将图片居中显示
    ui->lbl_Show1->setPixmap(QPixmap::fromImage(disImg));   //将图片显示在label上
}


void mainwindow::Trigger_Save() //保存处理后图片
{
    QImage img;
    //获取保存图片路径
    QString savePath = QFileDialog::getSaveFileName(this,"Save Image","../","Image Files (*.png *.jpeg *.jpg *.bmp);;All Files (*)");
    if(savePath.isEmpty())return;

    //判断是彩色图还是灰度图
    if(solvedImage.type()==CV_8UC1)img = QImage(solvedImage.data, solvedImage.cols, solvedImage.rows, solvedImage.cols * solvedImage.channels(),QImage::Format_Grayscale8);
    else img = QImage(solvedImage.data, solvedImage.cols, solvedImage.rows, solvedImage.cols * solvedImage.channels(),QImage::Format_RGB888);

    //保存格式
    if(savePath.contains(".jpg")||savePath.contains(".jpeg")||savePath.contains(".JPG")||savePath.contains(".JPEG"))img.save(savePath,"JPG",100);
    else if(savePath.contains(".png")||savePath.contains(".PNG"))img.save(savePath,"PNG",0);
    else if(savePath.contains(".bmp")||savePath.contains(".BMP"))img.save(savePath,"BMP",100);
    else return;
}

void mainwindow::on_btn_LoadImage_clicked() //显示原图
{
    // //弹出文件选择对话框，选择图片文件
    // QString imgPath = QFileDialog::getOpenFileName(this, "Open Image", "../Image/", "Image Files (*.png *.jpeg *.jpg *.bmp);;All Files (*)");
    // if(imgPath.isEmpty())return;
    // else if(!(imgPath.contains(".jpg")||imgPath.contains(".jpeg")||imgPath.contains(".JPG")||imgPath.contains(".JPEG")) &&\
    //          !(imgPath.contains(".png")||imgPath.contains(".PNG")) && !(imgPath.contains(".bmp")||imgPath.contains(".BMP")))return;

    // srcImage = imread(imgPath.toStdString());   //读取图片文件

    // cvtColor(srcImage, srcImage, COLOR_BGR2RGB);    //将BGR格式转换为RGB格式

    // //将读取的图片转换为QImage格式
    // QImage displayimg = QImage(srcImage.data, srcImage.cols, srcImage.rows, srcImage.cols * srcImage.channels(), QImage::Format_RGB888);
    
    // QImage disImg = imgCenter(displayimg,ui->lbl_Show1);    //将图片居中显示
    // ui->lbl_Show1->setPixmap(QPixmap::fromImage(disImg));   //将图片显示在label上
    Trigger_Open();
}


QImage mainwindow::imgCenter(QImage qImage, QLabel *qLabel) //图片居中显示
{
    QImage img;     //定义一个QImage变量img
    QSize imgSize = qImage.size();  //获取图片的大小
    QSize labelSize = qLabel->size();   //获取标签的大小

    //计算图片的宽高比例
    double dWidthRatio = 1.0 * imgSize.width() / labelSize.width();
    double dHeightRatio = 1.0 * imgSize.height() / labelSize.height();

    //如果宽高比例大于1，则将图片宽度缩放为标签的宽度，否则将图片高度缩放为标签的高度
    if(dWidthRatio > dHeightRatio)img = qImage.scaledToWidth(labelSize.width());

    else img = qImage.scaledToHeight(labelSize.height());   //否则按照高度比例缩放图片

    return img; //返回缩放后的图片
}


void mainwindow::Trigger_Gray()  //RGB图转灰度图
{
    Mat resultImg;  //定义需要返回的图片的变量
    if(srcImage.empty())return;

    cvtColor(srcImage, resultImg, COLOR_RGB2GRAY);  //将图片转换为灰度图
    solvedImage = resultImg;//获取完图
    cvtColor(resultImg, resultImg, COLOR_GRAY2RGB); //将灰度图转换回RGB图

    //将图片转换为QImage格式
    QImage displayimg = QImage(resultImg.data, resultImg.cols, resultImg.rows, resultImg.cols * resultImg.channels() , QImage::Format_RGB888);

    //将图片居中显示
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}

void mainwindow::Trigger_MeanImg() //均值滤波
{
    Mat blurImg;    // 定义一个模糊后的图像变量
    bool ok;        //判断
    if(srcImage.empty())return;
    Blurx = QInputDialog::getInt(this, "模糊程度量化", "输入x", 1, 1, 2147483647, 1, &ok);
    if(!ok)return;
    Blury = QInputDialog::getInt(this, "模糊程度量化", "输入y", 1, 1, 2147483647, 1, &ok);
    if(!ok)return;

    blur(srcImage, blurImg, Size(Blurx,Blury));   // 对原始图像进行模糊处理，Size中的两个参数分别表示x和y方向上的模糊程度

    solvedImage = blurImg;//获取完图

    // 将模糊后的图像转换为QImage格式并居中显示在label上
    QImage displayimg = QImage(blurImg.data, blurImg.cols, blurImg.rows, blurImg.cols * blurImg.channels(), QImage::Format_RGB888);
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}


void mainwindow::Trigger_Canny() //Canny算法
{
    Edge = Canny_D;//Canny算法
    Mat edgeImg,grayImg;    // 定义两个变量，一个用于存储边缘图，一个用于存储灰度图
    if(srcImage.empty())return;

    cvtColor(srcImage, grayImg, COLOR_RGB2GRAY);    //转换为灰度图

    Canny(srcImage, edgeImg, 200, 1);    //使用Canny算法提取边缘

    solvedImage = edgeImg;//获取完图

    cvtColor(edgeImg, edgeImg, COLOR_GRAY2RGB); // 转换为RGB格式

    // 将边缘图像转换为QImage格式并居中显示在label上
    QImage displayimg = QImage(edgeImg.data, edgeImg.cols, edgeImg.rows, edgeImg.cols * edgeImg.channels(), QImage::Format_RGB888);
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}

void mainwindow::Trigger_Laplacian() //Laplacian算法
{
    Edge = Laplacian_D;//Laplacian算法
    Mat edgeImg,grayImg;    // 定义两个变量，一个用于存储边缘图，一个用于存储灰度图
    if(srcImage.empty())return;

    cvtColor(srcImage, grayImg, COLOR_RGB2GRAY);    //转换为灰度图

    Laplacian(grayImg, edgeImg, grayImg.depth());    //使用Laplacian算子计算边缘图像

    solvedImage = edgeImg;//获取完图

    cvtColor(edgeImg, edgeImg, COLOR_GRAY2RGB); // 转换为RGB格式

    // 将边缘图像转换为QImage格式并居中显示在label上
    QImage displayimg = QImage(edgeImg.data, edgeImg.cols, edgeImg.rows, edgeImg.cols * edgeImg.channels(), QImage::Format_RGB888);
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}

void mainwindow::Trigger_Sobel() //Sobel算法
{
    Edge = Sobel_D;//Sobel算法
    Mat edgeImg,grayImg;    // 定义两个变量，一个用于存储边缘图，一个用于存储灰度图
    if(srcImage.empty())return;

    cvtColor(srcImage, grayImg, COLOR_RGB2GRAY);    //转换为灰度图

    Mat grad_x, grad_y;     // 定义两个变量，用于存储x和y方向的梯度

    Sobel(grayImg, grad_x, CV_8U, 1, 0);    // 计算x方向的梯度
    Sobel(grayImg, grad_y, CV_8U, 0, 1);    // 计算y方向的梯度

    addWeighted(grad_x, 0.5, grad_y, 0.5, 0, edgeImg);  // 计算x和y方向梯度的和作为边缘图像

    solvedImage = edgeImg;//获取完图

    cvtColor(edgeImg, edgeImg, COLOR_GRAY2RGB); // 转换为RGB格式

    // 将边缘图像转换为QImage格式并居中显示在label上
    QImage displayimg = QImage(edgeImg.data, edgeImg.cols, edgeImg.rows, edgeImg.cols * edgeImg.channels(), QImage::Format_RGB888);
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}


void mainwindow::on_btn_Gray_clicked()  //RGB图转灰度图
{
    // Mat resultImg;  //定义需要返回的图片的变量
    // if(srcImage.empty())return;

    // cvtColor(srcImage, resultImg, COLOR_RGB2GRAY);  //将图片转换为灰度图
    // solvedImage = resultImg;//获取完图
    // cvtColor(resultImg, resultImg, COLOR_GRAY2RGB); //将灰度图转换回RGB图

    // //将图片转换为QImage格式
    // QImage displayimg = QImage(resultImg.data, resultImg.cols, resultImg.rows, resultImg.cols * resultImg.channels() , QImage::Format_RGB888);
    
    // //将图片居中显示
    // QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    // ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
    Trigger_Gray();
}

void mainwindow::on_btn_MeanImage_clicked() //均值滤波
{
    // Mat blurImg;    // 定义一个模糊后的图像变量
    // if(srcImage.empty())return;

    // blur(srcImage, blurImg, Size(Blurx,Blury));   // 对原始图像进行模糊处理，Size中的两个参数分别表示x和y方向上的模糊程度
    // solvedImage = blurImg;//获取完图

    // // 将模糊后的图像转换为QImage格式并居中显示在label上
    // QImage displayimg = QImage(blurImg.data, blurImg.cols, blurImg.rows, blurImg.cols * blurImg.channels(), QImage::Format_RGB888);
    // QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    // ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
    Trigger_MeanImg();
}

void mainwindow::on_btn_Edge_clicked()
{
    Mat edgeImg,grayImg;    // 定义两个变量，一个用于存储边缘图，一个用于存储灰度图
    QStringList items;      //定义一个下拉选项列表
    QString qstr;           //定义一个判断对象
    bool ok;                //判断

    if(srcImage.empty())return;
    items << tr("Canny") << tr("Laplacian") << tr("Sobel");
    qstr = QInputDialog::getItem(this, "算法选择", "请选择边缘检测算法", items, 0, false, &ok);
    if(!ok)return;
    if(qstr == "Canny")Edge = Canny_D;
    else if(qstr == "Laplacian")Edge = Laplacian_D;
    else if(qstr == "Sobel")Edge = Sobel_D;

    cvtColor(srcImage, grayImg, COLOR_RGB2GRAY);    //转换为灰度图

    if(Edge == Canny_D)Canny(srcImage, edgeImg, 200, 1);    //使用Canny算法提取边缘

    else if(Edge == Laplacian_D)Laplacian(grayImg, edgeImg, grayImg.depth());    //使用Laplacian算子计算边缘图像

    else
    {
        Mat grad_x, grad_y;     // 定义两个变量，用于存储x和y方向的梯度

        Sobel(grayImg, grad_x, CV_8U, 1, 0);    // 计算x方向的梯度
        Sobel(grayImg, grad_y, CV_8U, 0, 1);    // 计算y方向的梯度

        addWeighted(grad_x, 0.5, grad_y, 0.5, 0, edgeImg);  // 计算x和y方向梯度的和作为边缘图像
    }

    solvedImage = edgeImg;//获取完图

    cvtColor(edgeImg, edgeImg, COLOR_GRAY2RGB); // 转换为RGB格式
    
    // 将边缘图像转换为QImage格式并居中显示在label上
    QImage displayimg = QImage(edgeImg.data, edgeImg.cols, edgeImg.rows, edgeImg.cols * edgeImg.channels(), QImage::Format_RGB888);
    QImage disImg = imgCenter(displayimg,ui->lbl_Show2);
    ui->lbl_Show2->setPixmap(QPixmap::fromImage(disImg));
}

void mainwindow::on_btn_Save_clicked()
{
    // QImage img;
    // //获取保存图片路径
    // QString savePath = QFileDialog::getSaveFileName(this,"Save Image","../Image/","Image Files (*.png *.jpeg *.jpg *.bmp);;All Files (*)");
    // if(savePath.isEmpty())return;

    // //判断是彩色图还是灰度图
    // if(solvedImage.type()==CV_8UC1)img = QImage(solvedImage.data, solvedImage.cols, solvedImage.rows, solvedImage.cols * solvedImage.channels(),QImage::Format_Grayscale8);
    // else img = QImage(solvedImage.data, solvedImage.cols, solvedImage.rows, solvedImage.cols * solvedImage.channels(),QImage::Format_RGB888);

    // //保存格式
    // if(savePath.contains(".jpg")||savePath.contains(".jpeg")||savePath.contains(".JPG")||savePath.contains(".JPEG"))img.save(savePath,"JPG",100);
    // else if(savePath.contains(".png")||savePath.contains(".PNG"))img.save(savePath,"PNG",0);
    // else if(savePath.contains(".bmp")||savePath.contains(".BMP"))img.save(savePath,"BMP",100);
    // else return;
    Trigger_Save();
}

