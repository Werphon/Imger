#pragma once
#include "ui_mainwindow.h"
#include <QMenuBar>//菜单栏
#include <QMenu>//菜单
#include <QAction>//菜单动作
#include <QToolBar>//工具栏
#include <QToolButton>//工具栏按键
#include <QStatusBar>//状态栏
#include <QMainWindow>//窗口
#include <QInputDialog>//输入对话框
#include <QFileDialog>//文件对话框
#include <QLabel>//标签
#include <opencv2/opencv.hpp>//OpenCV基础功能
#include <opencv2/highgui.hpp>//灰度图

using namespace cv;

class mainwindow : public QMainWindow {
    Q_OBJECT


//边缘检测枚举类
enum EdgeDetection{
    Canny_D = 0,
    Laplacian_D,
    Sobel_D
};


int Edge = Canny_D;//边缘检测算法默认为Canny
int Blurx = 1;//均值滤波x模糊值
int Blury = 1;//均值滤波y模糊值

public:
    mainwindow(QWidget* parent = nullptr);
    ~mainwindow();

    QImage imgCenter(QImage qImage, QLabel *qLabel);    // 函数：将QImage图片居中显示在QLabel上

private slots:
    void Trigger_Open(); //@slot:显示原图

    void Trigger_Save(); //@slot:保存处理后图片

    void Trigger_Gray(); //@slot:灰度图

    void Trigger_MeanImg(); //@slot:均值滤波

    void Trigger_Canny(); //@slot:Canny算法

    void Trigger_Laplacian(); //@slot:Laplacian算法

    void Trigger_Sobel(); //@slot:Sobel算法

    void on_btn_LoadImage_clicked();    //@slot:槽函数，当btn_LoadImage被点击时触发

    void on_btn_Gray_clicked();     //@slot:槽函数，当btn_Gray被点击时触发

    void on_btn_MeanImage_clicked();    //@slot:槽函数，当btn_MeanImage被点击时触发

    void on_btn_Edge_clicked();    //@slot:槽函数，当btn_Edge被点击时触发

    void on_btn_Save_clicked();

private:
    Ui_mainwindow* ui;
    Mat srcImage;   //原图
    Mat solvedImage;//完图
    QMenu *pMenuFile;//文件菜单
    QMenu *pMenuEdit;//编辑菜单
    QMenu *pMenuHelp;//帮助菜单
    QMenu *pMenuEdge;//边缘检测二级菜单
    QMenu *pMenuMean;//均值滤波二级菜单

    QAction *pActOpen;//打开
    QAction *pActSave;//保存
    QAction *pActGray;//灰度图
    QAction *pActMeanImg;//均值滤波
    QAction *pActAbout;//关于
    QAction *pActCanny;//Canny算法
    QAction *pActLaplacian;//Laplacian算法
    QAction *pActSobel;//Sobel算法
};
